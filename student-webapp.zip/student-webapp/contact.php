<?php
// contact.php - Contact page (protected)

// Include database configuration
require_once 'php/config.php';

// Check if user is logged in, redirect to login if not
requireLogin();

// Get current user data
startSession();
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = trim($_POST['message']);
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    
    $errors = array();
    
    // Validate message
    if (empty($message)) {
        $errors[] = "Message is required";
    }
    
    // Validate rating
    if ($rating < 1 || $rating > 5) {
        $errors[] = "Please select a rating from 1 to 5";
    }
    
    // If no errors, save to database
    if (empty($errors)) {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT INTO contacts (user_id, message, rating) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $user_id, $message, $rating);
        
        if ($stmt->execute()) {
            $success_message = "Thank you! Your message has been submitted successfully.";
        } else {
            $error_message = "Failed to submit message. Please try again.";
        }
        
        $stmt->close();
        $conn->close();
    } else {
        $error_message = implode(", ", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Student Web App</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <div class="logo">StudentApp</div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="php/logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <div class="form-container">
                <div class="card">
                    <h2>Contact Form</h2>
                    <p>Hello <?php echo htmlspecialchars($user_name); ?>! Send us your feedback.</p>
                    
                    <!-- Display success or error messages -->
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-error"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <!-- Contact Form -->
                    <form id="contactForm" method="POST">
                        <div class="form-group">
                            <label for="message">Your Message:</label>
                            <textarea id="message" name="message" rows="5" class="form-control" 
                                      placeholder="Enter your message here..." required></textarea>
                            <div class="error-message" id="messageError"></div>
                        </div>

                        <div class="form-group">
                            <label>Rate our service:</label>
                            <div class="rating">
                                <input type="radio" id="star5" name="rating" value="5">
                                <label for="star5">⭐</label>
                                
                                <input type="radio" id="star4" name="rating" value="4">
                                <label for="star4">⭐</label>
                                
                                <input type="radio" id="star3" name="rating" value="3">
                                <label for="star3">⭐</label>
                                
                                <input type="radio" id="star2" name="rating" value="2">
                                <label for="star2">⭐</label>
                                
                                <input type="radio" id="star1" name="rating" value="1">
                                <label for="star1">⭐</label>
                            </div>
                            <div class="error-message" id="ratingError"></div>
                        </div>

                        <button type="submit" class="btn btn-block">Submit Message</button>
                    </form>

                    <p style="text-align: center; margin-top: 15px;">
                        <a href="profile.php">Back to Profile</a>
                    </p>
                </div>
            </div>
        </div>
    </main>

    <!-- Success Modal -->
    <div id="successModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h3>Message Submitted!</h3>
            <p>Thank you for your feedback.</p>
            <button class="btn" onclick="closeModal()">Close</button>
        </div>
    </div>

    <style>
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        .rating {
            display: flex;
            flex-direction: row-reverse;
            justify-content: center;
            gap: 5px;
            margin: 10px 0;
        }
        
        .rating input {
            display: none;
        }
        
        .rating label {
            font-size: 30px;
            color: #ddd;
            cursor: pointer;
            transition: color 0.3s;
        }
        
        .rating label:hover,
        .rating label:hover ~ label,
        .rating input:checked ~ label {
            color: #ffc107;
        }
    </style>

    <!-- JavaScript -->
    <script src="js/script.js"></script>
    
    <?php if (isset($success_message)): ?>
    <script>
        // Show success modal if form was submitted successfully
        showModal('successModal');
    </script>
    <?php endif; ?>
</body>
</html>