<?php
echo "<h2>Debug Connection Test</h2>";

// Test 1: Direct connection with empty password
echo "<h3>Test 1: Empty password</h3>";
try {
    $conn1 = new mysqli('localhost', 'root', '', 'student_webapp');
    echo "✅ SUCCESS with empty password!<br>";
    $conn1->close();
} catch (Exception $e) {
    echo "❌ FAILED with empty password: " . $e->getMessage() . "<br>";
}

// Test 2: Direct connection with password '1234'
echo "<h3>Test 2: Password '1234'</h3>";
try {
    $conn2 = new mysqli('localhost', 'root', '1234', 'student_webapp');
    echo "✅ SUCCESS with password '1234'!<br>";
    $conn2->close();
} catch (Exception $e) {
    echo "❌ FAILED with password '1234': " . $e->getMessage() . "<br>";
}

// Test 3: Test with 127.0.0.1
echo "<h3>Test 3: Using 127.0.0.1</h3>";
try {
    $conn3 = new mysqli('127.0.0.1', 'root', '', 'student_webapp');
    echo "✅ SUCCESS with 127.0.0.1!<br>";
    $conn3->close();
} catch (Exception $e) {
    echo "❌ FAILED with 127.0.0.1: " . $e->getMessage() . "<br>";
}

echo "<h3>Current config.php settings:</h3>";
include 'php/config.php';
echo "Host: " . (isset($host) ? $host : 'NOT SET') . "<br>";
echo "Username: " . (isset($username) ? $username : 'NOT SET') . "<br>";
echo "Password: '" . (isset($password) ? $password : 'NOT SET') . "'<br>";
echo "Database: " . (isset($database) ? $database : 'NOT SET') . "<br>";
?>