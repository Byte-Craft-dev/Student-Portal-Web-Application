// script.js - JavaScript functions for form validation and interactivity

// Function to toggle password visibility
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    const toggleButton = passwordInput.nextElementSibling;
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = '🙈';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = '👁️';
    }
}

// Function to validate email format
function validateEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}

// Function to validate password (minimum 8 characters)
function validatePassword(password) {
    return password.length >= 8;
}

// Function to show error message
function showError(inputId, message) {
    const input = document.getElementById(inputId);
    const errorDiv = document.getElementById(inputId + 'Error');
    
    input.classList.add('error');
    errorDiv.textContent = message;
}

// Function to clear error message
function clearError(inputId) {
    const input = document.getElementById(inputId);
    const errorDiv = document.getElementById(inputId + 'Error');
    
    input.classList.remove('error');
    errorDiv.textContent = '';
}

// Function to validate registration form
function validateRegistrationForm() {
    let isValid = true;
    
    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Clear previous errors
    clearError('name');
    clearError('email');
    clearError('password');
    clearError('confirmPassword');
    
    // Validate name (not empty)
    if (name === '') {
        showError('name', 'Name is required');
        isValid = false;
    }
    
    // Validate email
    if (email === '') {
        showError('email', 'Email is required');
        isValid = false;
    } else if (!validateEmail(email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate password
    if (password === '') {
        showError('password', 'Password is required');
        isValid = false;
    } else if (!validatePassword(password)) {
        showError('password', 'Password must be at least 8 characters long');
        isValid = false;
    }
    
    // Validate confirm password
    if (confirmPassword === '') {
        showError('confirmPassword', 'Please confirm your password');
        isValid = false;
    } else if (password !== confirmPassword) {
        showError('confirmPassword', 'Passwords do not match');
        isValid = false;
    }
    
    return isValid;
}

// Function to validate login form
function validateLoginForm() {
    let isValid = true;
    
    // Get form values
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    // Clear previous errors
    clearError('email');
    clearError('password');
    
    // Validate email
    if (email === '') {
        showError('email', 'Email is required');
        isValid = false;
    } else if (!validateEmail(email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }
    
    // Validate password
    if (password === '') {
        showError('password', 'Password is required');
        isValid = false;
    }
    
    return isValid;
}

// Function to validate contact form
function validateContactForm() {
    let isValid = true;
    
    // Get form values
    const message = document.getElementById('message').value.trim();
    const rating = document.querySelector('input[name="rating"]:checked');
    
    // Clear previous errors
    clearError('message');
    clearError('rating');
    
    // Validate message
    if (message === '') {
        showError('message', 'Message is required');
        isValid = false;
    }
    
    // Validate rating
    if (!rating) {
        showError('rating', 'Please select a rating');
        isValid = false;
    }
    
    return isValid;
}

// Function to show modal
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
    }
}

// Function to close modal
function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
}

// Function to handle rating selection
function selectRating(rating) {
    // Clear all stars
    const stars = document.querySelectorAll('.rating label');
    stars.forEach(star => star.classList.remove('active'));
    
    // Highlight selected stars
    for (let i = 0; i < rating; i++) {
        stars[i].classList.add('active');
    }
}

// Event listeners when page loads
document.addEventListener('DOMContentLoaded', function() {
    
    // Registration form validation
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            if (!validateRegistrationForm()) {
                e.preventDefault(); // Prevent form submission if validation fails
            }
        });
    }
    
    // Login form validation
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            if (!validateLoginForm()) {
                e.preventDefault(); // Prevent form submission if validation fails
            }
        });
    }
    
    // Contact form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            if (!validateContactForm()) {
                e.preventDefault(); // Prevent form submission if validation fails
            }
        });
    }
    
    // Rating system event listeners
    const ratingInputs = document.querySelectorAll('.rating input');
    ratingInputs.forEach(input => {
        input.addEventListener('change', function() {
            selectRating(this.value);
        });
    });
    
    // Close modal when clicking outside of it
    window.addEventListener('click', function(e) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
});

// Real-time validation for better user experience
document.addEventListener('DOMContentLoaded', function() {
    // Email validation on blur
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value.trim() !== '' && !validateEmail(this.value.trim())) {
                showError(this.id, 'Please enter a valid email address');
            } else {
                clearError(this.id);
            }
        });
    });
    
    // Password validation on blur
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        if (input.id === 'password') {
            input.addEventListener('blur', function() {
                if (this.value !== '' && !validatePassword(this.value)) {
                    showError(this.id, 'Password must be at least 8 characters long');
                } else {
                    clearError(this.id);
                }
            });
        }
    });
});