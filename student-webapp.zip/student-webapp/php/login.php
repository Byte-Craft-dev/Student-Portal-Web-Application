<?php
// login.php - Handle user login with direct connection

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Database connection - DIRECT (no config.php)
    $host = 'localhost';
    $username = 'root';
    $password = '1234';  // Your working password
    $database = 'student_webapp';
    
    // Get form data and sanitize
    $email = trim($_POST['email']);
    $user_password = $_POST['password'];
    
    $errors = array();
    
    // Server-side validation
    
    // Validate email
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Validate password
    if (empty($user_password)) {
        $errors[] = "Password is required";
    }
    
    // If no validation errors, check credentials
    if (empty($errors)) {
        try {
            $conn = new mysqli($host, $username, $password, $database);
            
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            
            // Get user from database
            $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                // Verify password
                if (password_verify($user_password, $user['password'])) {
                    // Password is correct, start session
                    session_start();
                    
                    // Store user data in session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    
                    $stmt->close();
                    $conn->close();
                    
                    // Login successful - redirect to profile page
                    header("Location: ../profile.php");
                    exit();
                } else {
                    $errors[] = "Invalid email or password";
                }
            } else {
                $errors[] = "Invalid email or password";
            }
            
            $stmt->close();
            $conn->close();
            
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    // If there are errors, display them
    if (!empty($errors)) {
        echo "<script>";
        echo "alert('Login failed:\\n";
        foreach ($errors as $error) {
            echo "- " . $error . "\\n";
        }
        echo "');";
        echo "window.history.back();";
        echo "</script>";
    }
    
} else {
    // If not POST request, redirect to login page
    header("Location: ../login.html");
    exit();
}
?>