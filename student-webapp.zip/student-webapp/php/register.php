<?php
// register.php - Handle user registration with direct connection

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Database connection - DIRECT (no config.php)
    $host = 'localhost';
    $username = 'root';
    $password = '1234';  // Your working password
    $database = 'student_webapp';
    
    // Get form data and sanitize
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $user_password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    
    $errors = array();
    
    // Server-side validation
    
    // Validate name
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    // Validate email
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    // Validate password
    if (empty($user_password)) {
        $errors[] = "Password is required";
    } elseif (strlen($user_password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }
    
    // Validate confirm password
    if (empty($confirmPassword)) {
        $errors[] = "Please confirm your password";
    } elseif ($user_password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }
    
    // Check if email already exists
    if (empty($errors)) {
        try {
            $conn = new mysqli($host, $username, $password, $database);
            
            if ($conn->connect_error) {
                throw new Exception("Connection failed: " . $conn->connect_error);
            }
            
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $errors[] = "Email already exists";
            }
            $stmt->close();
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
    
    // If no errors, insert user into database
    if (empty($errors)) {
        try {
            // Hash the password
            $hashedPassword = password_hash($user_password, PASSWORD_DEFAULT);
            
            // Insert user into database
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashedPassword);
            
            if ($stmt->execute()) {
                $stmt->close();
                $conn->close();
                
                // Registration successful - redirect to login page
                echo "<script>
                        alert('Registration successful! You can now login.');
                        window.location.href = '../login.html';
                      </script>";
                exit();
            } else {
                $errors[] = "Registration failed. Please try again.";
            }
            
            $stmt->close();
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
        
        if (isset($conn)) {
            $conn->close();
        }
    }
    
    // If there are errors, display them
    if (!empty($errors)) {
        echo "<script>";
        echo "alert('Registration failed:\\n";
        foreach ($errors as $error) {
            echo "- " . $error . "\\n";
        }
        echo "');";
        echo "window.history.back();";
        echo "</script>";
    }
    
} else {
    // If not POST request, redirect to registration page
    header("Location: ../register.html");
    exit();
}
?>