<?php
// profile.php - Student profile page (protected)

// Include database configuration
require_once 'php/config.php';

// Check if user is logged in, redirect to login if not
requireLogin();

// Get current user data
startSession();
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];
$user_id = $_SESSION['user_id'];

// Get user registration date from database
$conn = getConnection();
$stmt = $conn->prepare("SELECT created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Student Web App</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-content">
                <div class="logo">StudentApp</div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="php/logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <div class="container">
            <div class="card">
                <h2>Student Profile</h2>
                
                <div class="profile-info">
                    <div class="profile-item">
                        <strong>Name:</strong> <?php echo htmlspecialchars($user_name); ?>
                    </div>
                    
                    <div class="profile-item">
                        <strong>Email:</strong> <?php echo htmlspecialchars($user_email); ?>
                    </div>
                    
                    <div class="profile-item">
                        <strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($user_data['created_at'])); ?>
                    </div>
                    
                    <div class="profile-item">
                        <strong>User ID:</strong> <?php echo $user_id; ?>
                    </div>
                </div>

                <div style="margin-top: 30px;">
                    <h3>Available Actions:</h3>
                    <div class="profile-actions">
                        <a href="contact.php" class="btn">Send Contact Message</a>
                        <a href="php/logout.php" class="btn btn-danger">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <style>
        .profile-info {
            margin: 20px 0;
        }
        
        .profile-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .profile-item:last-child {
            border-bottom: none;
        }
        
        .profile-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 480px) {
            .profile-actions {
                flex-direction: column;
            }
        }
    </style>

    <!-- JavaScript -->
    <script src="js/script.js"></script>
</body>
</html>