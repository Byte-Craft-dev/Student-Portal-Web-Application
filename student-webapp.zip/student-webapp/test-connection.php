<?php
// Test the connection
$host = 'localhost';
$username = 'root';
$password = '';  // Empty for Laragon
$database = 'student_webapp';

echo "Testing connection...<br>";
try {
    $conn = new mysqli($host, $username, $password, $database);
    echo "✅ SUCCESS! Database connected<br>";
    echo "Database: " . $database . "<br>";
    
    // Test if tables exist
    $result = $conn->query("SHOW TABLES");
    echo "Tables found: " . $result->num_rows . "<br>";
    
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage();
}
?>