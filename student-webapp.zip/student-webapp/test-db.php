<?php
// Test database connection
$host = '127.0.0.1';
$username = 'root';
$password = '';  // Try empty first
$database = 'student_webapp';

echo "Testing database connection...<br>";
echo "Host: $host<br>";
echo "Username: $username<br>";
echo "Password: " . (empty($password) ? '(empty)' : '(set)') . "<br>";
echo "Database: $database<br><br>";

try {
    $conn = new mysqli($host, $username, $password);
    echo "✅ MySQL connection successful!<br>";
    
    // Check if database exists
    $result = $conn->query("SHOW DATABASES LIKE 'student_webapp'");
    if ($result->num_rows > 0) {
        echo "✅ Database 'student_webapp' exists!<br>";
    } else {
        echo "❌ Database 'student_webapp' does not exist!<br>";
        echo "Please create the database first.<br>";
    }
    
} catch (mysqli_sql_exception $e) {
    echo "❌ Connection failed: " . $e->getMessage() . "<br>";
    echo "<br>Try these solutions:<br>";
    echo "1. Make sure Laragon MySQL is running<br>";
    echo "2. Try password = '1234' instead of empty<br>";
    echo "3. Use 'localhost' instead of '127.0.0.1'<br>";
}
?>