<?php
// Test the exact same way register.php connects
require_once 'php/config.php';

echo "<h2>Testing Register Connection</h2>";

try {
    $conn = getConnection();
    echo "✅ SUCCESS! Connection works exactly like register.php<br>";
    echo "✅ Database connection established<br>";
    
    // Test if we can query users table
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $row = $result->fetch_assoc();
    echo "✅ Users table accessible. Current users: " . $row['count'] . "<br>";
    
    $conn->close();
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "<br>";
}
?>